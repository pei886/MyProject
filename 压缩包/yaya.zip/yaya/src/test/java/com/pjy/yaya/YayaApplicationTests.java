package com.pjy.yaya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YayaApplicationTests {

	@Test
	void contextLoads() {
	}

}
